
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, ChevronRight, ChevronLeft, Award, Users, TrendingUp } from 'lucide-react@0.487.0';
import { ImageWithFallback } from '../figma/ImageWithFallback';

// Mock startup data
const startups = [
  {
    id: 1,
    name: "QuantumVision AI",
    category: "Artificial Intelligence",
    description: "Computer vision solutions for manufacturing quality control and defect detection.",
    image: "https://images.unsplash.com/photo-1581092921461-7d65ca45393a?q=80&w=2070&auto=format&fit=crop",
    logo: "https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?q=80&w=2069&auto=format&fit=crop",
    rating: 4.9,
    reviewCount: 128,
    tags: ["AI & ML", "Manufacturing", "Computer Vision"],
    bgColor: "rgba(193, 241, 126, 0.2)",
    metrics: {
      funding: "$2.4M",
      customers: 42,
      growth: "163%"
    }
  },
  {
    id: 2,
    name: "OceanGuard Tech",
    category: "Environmental Tech",
    description: "Ocean plastic cleanup technology using autonomous drones and AI sorting systems.",
    image: "https://images.unsplash.com/photo-1621451537084-482c73073a0f?q=80&w=1974&auto=format&fit=crop",
    logo: "https://images.unsplash.com/photo-1560179304-6fc1d8749b23?q=80&w=1973&auto=format&fit=crop",
    rating: 4.7,
    reviewCount: 93,
    tags: ["CleanTech", "Robotics", "Environmental"],
    bgColor: "rgba(138, 79, 255, 0.2)",
    metrics: {
      funding: "$3.8M",
      customers: 8,
      growth: "127%"
    }
  },
  {
    id: 3,
    name: "NutriGenomics",
    category: "Health Tech",
    description: "Personalized nutrition recommendations based on genetic analysis and health markers.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?q=80&w=2070&auto=format&fit=crop",
    logo: "https://images.unsplash.com/photo-1612836584099-100624d531c9?q=80&w=1974&auto=format&fit=crop",
    rating: 4.8,
    reviewCount: 107,
    tags: ["HealthTech", "Genomics", "Nutrition"],
    bgColor: "rgba(255, 107, 0, 0.2)",
    metrics: {
      funding: "$5.2M",
      customers: 15000,
      growth: "218%"
    }
  },
  {
    id: 4,
    name: "Neurofeedback VR",
    category: "Mental Health",
    description: "Virtual reality therapy using real-time brain activity monitoring and biofeedback.",
    image: "https://images.unsplash.com/photo-1593508512255-86ab42a8e620?q=80&w=2066&auto=format&fit=crop",
    logo: "https://images.unsplash.com/photo-1548372290-8d01b6c8e78c?q=80&w=2069&auto=format&fit=crop",
    rating: 4.6,
    reviewCount: 64,
    tags: ["VR/AR", "Mental Health", "Neuroscience"],
    bgColor: "rgba(0, 102, 255, 0.2)",
    metrics: {
      funding: "$1.8M",
      customers: 28,
      growth: "94%"
    }
  }
];

export function TopStartups() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const [autoplayEnabled, setAutoplayEnabled] = useState(true);

  // Handle automatic sliding
  useEffect(() => {
    if (!autoplayEnabled || isHovering) return;
    
    const interval = setInterval(() => {
      nextSlide();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [currentIndex, autoplayEnabled, isHovering]);

  const nextSlide = () => {
    setDirection(1);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % startups.length);
  };

  const prevSlide = () => {
    setDirection(-1);
    setCurrentIndex((prevIndex) => (prevIndex - 1 + startups.length) % startups.length);
  };

  return (
    <div className="max-w-7xl mx-auto">
      {/* Section header with improved contrast and spacing */}
      <div className="flex justify-between items-end flex-wrap mb-14">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-lg"
        >
          <h2 className="text-4xl font-bold text-white mb-3 flex items-center">
            Featured <span className="text-primary ml-2">Startups</span>
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              <Award className="ml-3 text-primary h-7 w-7" />
            </motion.div>
          </h2>
          <p className="text-foreground/70 max-w-lg text-lg">
            Discover trending startups making waves in our ecosystem
          </p>
        </motion.div>
        
        {/* Enhanced navigation controls with active state indicators */}
        <motion.div 
          className="flex space-x-3 mt-4 sm:mt-0"
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <motion.button
            className="w-12 h-12 rounded-full flex items-center justify-center border border-foreground/20 text-foreground relative overflow-hidden group"
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 0 20px rgba(193, 241, 126, 0.15)"
            }}
            whileTap={{ scale: 0.95 }}
            onClick={prevSlide}
          >
            <motion.div 
              className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100"
              initial={{ scale: 0 }}
              whileHover={{ scale: 1 }}
              transition={{ duration: 0.3 }}
              style={{ borderRadius: "inherit" }}
            />
            <ChevronLeft size={20} className="relative z-10 group-hover:text-primary transition-colors" />
          </motion.button>
          
          <motion.button
            className="w-12 h-12 rounded-full flex items-center justify-center border border-foreground/20 text-foreground relative overflow-hidden group"
            whileHover={{ 
              scale: 1.05,
              boxShadow: "0 0 20px rgba(193, 241, 126, 0.15)"
            }}
            whileTap={{ scale: 0.95 }}
            onClick={nextSlide}
          >
            <motion.div 
              className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100" 
              initial={{ scale: 0 }}
              whileHover={{ scale: 1 }}
              transition={{ duration: 0.3 }}
              style={{ borderRadius: "inherit" }}
            />
            <ChevronRight size={20} className="relative z-10 group-hover:text-primary transition-colors" />
          </motion.button>
        </motion.div>
      </div>
      
      {/* Enhanced startup carousel with improved visuals and animation */}
      <div 
        className="relative overflow-hidden"
        onMouseEnter={() => setIsHovering(true)}
        onMouseLeave={() => setIsHovering(false)}
      >
        <AnimatePresence initial={false} mode="wait" custom={direction}>
          <motion.div 
            key={currentIndex}
            custom={direction}
            initial={{ opacity: 0, x: direction * 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: direction * -50 }}
            transition={{ duration: 0.5, ease: [0.32, 0.72, 0, 1] }}
            className="grid grid-cols-1 md:grid-cols-2 gap-8"
          >
            {/* Left side - Featured startup image with overlay info */}
            <motion.div 
              className="rounded-2xl overflow-hidden relative h-[500px] md:h-auto"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7 }}
            >
              <div className="absolute inset-0 w-full h-full">
                <ImageWithFallback 
                  src={startups[currentIndex].image}
                  alt={startups[currentIndex].name}
                  className="w-full h-full object-cover"
                />
                
                {/* Enhanced gradient overlay with more depth */}
                <div 
                  className="absolute inset-0"
                  style={{ 
                    background: "linear-gradient(to bottom, rgba(8, 15, 23, 0.2) 0%, rgba(8, 15, 23, 0.8) 80%, rgba(8, 15, 23, 0.95) 100%)",
                    backdropFilter: "blur(1px)"
                  }}
                />
                
                {/* Startup logo with improved prominence */}
                <motion.div 
                  className="absolute top-6 left-6 flex items-center gap-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                >
                  <div 
                    className="w-16 h-16 rounded-xl overflow-hidden border-2 border-white/10 shadow-lg"
                    style={{ 
                      background: "#1e1e1e",
                      boxShadow: "0 4px 24px rgba(0, 0, 0, 0.4)" 
                    }}
                  >
                    <ImageWithFallback 
                      src={startups[currentIndex].logo} 
                      alt={`${startups[currentIndex].name} logo`}
                      className="w-full h-full object-cover" 
                    />
                  </div>
                  
                  <div>
                    <div 
                      className="py-1 px-3 rounded-full text-xs font-medium inline-flex items-center mb-1"
                      style={{ 
                        background: "rgba(8, 15, 23, 0.7)",
                        backdropFilter: "blur(10px)" 
                      }}
                    >
                      {startups[currentIndex].category}
                    </div>
                    <div 
                      className="py-1 px-3 rounded-full flex items-center"
                      style={{ 
                        background: "rgba(8, 15, 23, 0.7)",
                        backdropFilter: "blur(10px)" 
                      }}
                    >
                      <Star className="text-primary mr-1" size={16} fill="#c1f17e" />
                      <span className="text-white font-medium">{startups[currentIndex].rating}</span>
                      <span className="text-foreground/60 text-sm ml-1">({startups[currentIndex].reviewCount})</span>
                    </div>
                  </div>
                </motion.div>
                
                {/* Bottom info section with name and improved metrics display */}
                <div className="absolute bottom-0 left-0 w-full p-6">
                  <motion.h3 
                    className="text-3xl font-bold text-white mb-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2, duration: 0.5 }}
                  >
                    {startups[currentIndex].name}
                  </motion.h3>
                  
                  <motion.p 
                    className="text-foreground/80 mb-6 max-w-lg"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.5 }}
                  >
                    {startups[currentIndex].description}
                  </motion.p>
                  
                  {/* Startup metrics with icons */}
                  <motion.div 
                    className="grid grid-cols-3 gap-4 mb-6"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 0.5 }}
                  >
                    <div className="bg-background/30 backdrop-blur-md rounded-lg p-3 border border-white/5">
                      <div className="flex items-center text-primary text-sm font-medium mb-1">
                        <Award size={14} className="mr-1" />
                        Funding
                      </div>
                      <div className="text-white font-bold">
                        {startups[currentIndex].metrics.funding}
                      </div>
                    </div>
                    
                    <div className="bg-background/30 backdrop-blur-md rounded-lg p-3 border border-white/5">
                      <div className="flex items-center text-primary text-sm font-medium mb-1">
                        <Users size={14} className="mr-1" />
                        Customers
                      </div>
                      <div className="text-white font-bold">
                        {startups[currentIndex].metrics.customers.toLocaleString()}
                      </div>
                    </div>
                    
                    <div className="bg-background/30 backdrop-blur-md rounded-lg p-3 border border-white/5">
                      <div className="flex items-center text-primary text-sm font-medium mb-1">
                        <TrendingUp size={14} className="mr-1" />
                        Growth
                      </div>
                      <div className="text-white font-bold">
                        {startups[currentIndex].metrics.growth}
                      </div>
                    </div>
                  </motion.div>
                  
                  {/* Tags with improved styling */}
                  <motion.div 
                    className="flex flex-wrap gap-2"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                  >
                    {startups[currentIndex].tags.map((tag, idx) => (
                      <span 
                        key={idx} 
                        className="px-3 py-1 rounded-full text-sm font-medium inline-flex items-center"
                        style={{ 
                          background: idx === 0 ? startups[currentIndex].bgColor : "rgba(214, 221, 230, 0.1)",
                          color: idx === 0 ? "#c1f17e" : "#d6dde6",
                          border: idx === 0 ? "1px solid rgba(193, 241, 126, 0.3)" : "1px solid rgba(214, 221, 230, 0.1)"
                        }}
                      >
                        {tag}
                      </span>
                    ))}
                  </motion.div>
                </div>
              </div>
            </motion.div>
            
            {/* Right side - Other startups in smaller cards */}
            <div className="space-y-6">
              {startups.filter((_, idx) => idx !== currentIndex).map((startup, idx) => (
                <motion.div 
                  key={startup.id}
                  className="rounded-xl overflow-hidden cursor-pointer hover:shadow-xl transition-all duration-300 relative border border-white/5"
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + (idx * 0.1), duration: 0.5 }}
                  onClick={() => {
                    setDirection(idx < currentIndex ? -1 : 1);
                    setCurrentIndex(startups.findIndex(s => s.id === startup.id));
                  }}
                  whileHover={{ 
                    y: -5,
                    boxShadow: "0 20px 30px -10px rgba(0, 0, 0, 0.3), 0 0 15px rgba(193, 241, 126, 0.15)"
                  }}
                  style={{ 
                    background: "rgba(30, 30, 30, 0.6)",
                    backdropFilter: "blur(10px)",
                  }}
                >
                  <div className="flex items-start p-4 gap-4">
                    {/* Startup logo */}
                    <div className="w-12 h-12 rounded-lg overflow-hidden flex-shrink-0 border border-white/10">
                      <ImageWithFallback 
                        src={startup.logo} 
                        alt={`${startup.name} logo`}
                        className="w-full h-full object-cover" 
                      />
                    </div>
                    
                    {/* Startup info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="text-white font-bold truncate">{startup.name}</h4>
                          <p className="text-foreground/70 text-sm">{startup.category}</p>
                        </div>
                        
                        <div className="flex items-center bg-background/50 py-0.5 px-2 rounded-full">
                          <Star className="text-primary mr-1" size={14} fill="#c1f17e" />
                          <span className="text-white text-sm font-medium">{startup.rating}</span>
                        </div>
                      </div>
                      
                      <p className="text-foreground/80 text-sm mt-2 line-clamp-2">
                        {startup.description}
                      </p>
                      
                      {/* Tags - simplified for smaller cards */}
                      <div className="flex flex-wrap gap-1 mt-3">
                        {startup.tags.slice(0, 2).map((tag, tagIdx) => (
                          <span 
                            key={tagIdx} 
                            className="px-2 py-0.5 rounded-full text-xs font-medium"
                            style={{ 
                              background: tagIdx === 0 ? startup.bgColor : "rgba(214, 221, 230, 0.1)",
                              color: tagIdx === 0 ? "#c1f17e" : "#d6dde6"
                            }}
                          >
                            {tag}
                          </span>
                        ))}
                        {startup.tags.length > 2 && (
                          <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-foreground/10">
                            +{startup.tags.length - 2}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
              
              {/* Enhanced View All button */}
              <motion.button
                className="w-full py-3 rounded-xl font-medium flex items-center justify-center transition-all duration-300 group relative overflow-hidden"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6, duration: 0.5 }}
                style={{ 
                  background: "linear-gradient(90deg, rgba(193, 241, 126, 0.1) 0%, rgba(193, 241, 126, 0.2) 100%)",
                  border: "1px solid rgba(193, 241, 126, 0.3)"
                }}
                whileHover={{ 
                  boxShadow: "0 0 20px rgba(193, 241, 126, 0.2)"
                }}
                whileTap={{ scale: 0.98 }}
              >
                <motion.span
                  className="absolute inset-0 bg-primary/10 opacity-0"
                  initial={{ x: "-100%" }}
                  whileHover={{ x: "0%", opacity: 1 }}
                  transition={{ duration: 0.4 }}
                />
                <span className="text-primary relative z-10 flex items-center">
                  View All Startups
                  <ChevronRight size={18} className="ml-1 group-hover:translate-x-1 transition-transform" />
                </span>
              </motion.button>
            </div>
          </motion.div>
        </AnimatePresence>
        
        {/* Enhanced pagination dots with animated current indicator */}
        <div className="flex justify-center mt-10 space-x-3">
          {startups.map((_, idx) => (
            <button
              key={idx}
              onClick={() => {
                setDirection(idx < currentIndex ? -1 : 1);
                setCurrentIndex(idx);
              }}
              className="group relative"
              aria-label={`Go to slide ${idx + 1}`}
            >
              <div 
                className={`w-2 h-2 rounded-full transition-all duration-300 ${
                  idx === currentIndex 
                    ? "bg-primary" 
                    : "bg-foreground/20 group-hover:bg-foreground/40"
                }`}
              />
              {idx === currentIndex && (
                <motion.div 
                  className="absolute -inset-2 rounded-full border border-primary/50"
                  layoutId="activeDot"
                  transition={{ duration: 0.3, type: "spring" }}
                />
              )}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
